package promise.uiapp.models

import android.view.View
import android.widget.TextView
import promise.promiseui.model.ViewHolder
import promise.promiseui.model.ViewableCallback
import promise.promiseui.scopes.Viewable
import promise.uiapp.R

class ViewPoJoHolder : ViewHolder() {
  lateinit var textView: TextView
}

class ViewPoJoCallbackInstance : ViewableCallback<ViewablePoJo, ViewPoJoHolder> {
  override fun init(view: View): ViewPoJoHolder {
    val holder = ViewPoJoHolder()
    holder.textView = view.findViewById(R.id.pojo_text)
    return holder
  }

  override fun onBind(t: ViewablePoJo, view: ViewPoJoHolder) {
    view.textView.text = t.text
  }
}

@Viewable(layout = R.layout.pojo_layout, viewableCallbackClass = ViewPoJoCallbackInstance::class)
class ViewablePoJo(val text: String)