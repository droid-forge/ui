package promise.uiapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import promise.commons.model.List
import promise.promiseui.PromiseAdapter
import promise.uiapp.models.ViewablePoJo


inline fun <T> generate(num: Int, function: (Int) -> T): List<T> {
  val list = List<T>()
  for (i in 0 until num) {
    list.add(function(i))
  }
  return list
}

class MainActivity : AppCompatActivity() {

  lateinit var adapter: PromiseAdapter<ViewablePoJo>

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)

    recycler_view.adapter = adapter
    adapter.add(generate(10) {
      ViewablePoJo("text $it")
    })


  }
}
