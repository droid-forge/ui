/*
 *
 *  * Copyright 2017, Peter Vincent
 *  * Licensed under the Apache License, Version 2.0, Promise.
 *  * you may not use this file except in compliance with the License.
 *  * You may obtain a copy of the License at
 *  * http://www.apache.org/licenses/LICENSE-2.0
 *  * Unless required by applicable law or agreed to in writing,
 *  * software distributed under the License is distributed on an "AS IS" BASIS,
 *  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  * See the License for the specific language governing permissions and
 *  * limitations under the License.
 *
 */

package promise.promiseui;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;

import promise.commons.Promise;
import promise.commons.data.log.LogUtil;
import promise.commons.model.List;
import promise.commons.util.Conditions;
import promise.promiseui.anim.Anim;
import promise.promiseui.anim.AnimDuration;
import promise.promiseui.anim.Animator;
import promise.promiseui.model.Viewable;
import promise.promiseui.model.ViewableInstance;

/**
 * Created by yoctopus on 11/6/17.
 */
public class PromiseAdapter<T>
    extends RecyclerView.Adapter<PromiseAdapter<T>.Holder> {
  private String TAG = LogUtil.makeTag(PromiseAdapter.class);
  private String AdapterItems = "__adapter_items__";
  private Indexer indexer;
  private List<ViewableInstance<T>> list;
  private Listener<T> listener;
  private LongClickListener<T> longClickListener;
  private Swipe<T> swipeListener;
  private Anim anim;
  private AnimDuration animDuration;
  private AnimDuration waitDuration;
  private int alternatingColor = 0;
  private OnAfterInitListener onAfterInitListener;

  public PromiseAdapter(@NonNull Listener<T> listener) {
    this(new List<>(), listener);
  }

  public PromiseAdapter(@NonNull List<T> list, @NonNull Listener<T> listener) {
    this.list = Conditions.checkNotNull(list.map(ViewableInstance::new));
    this.listener = listener;
    indexList();
  }

 /* public void restoreViewState(Bundle instanceState) {
    List<Parcelable> items = new List<>(instanceState.getParcelableArrayList(AdapterItems));
    if (items.isEmpty()) return;
    this.list = items.map(parcelable -> (T) parcelable);
    indexList();
  }

  public void backupViewState(Bundle instanceState) {
    instanceState.putParcelableArrayList(AdapterItems, new ArrayList<>(list.map(t -> (Parcelable) t)));
  }*/

  @Deprecated
  public void destroyViewState() {

  }

  public PromiseAdapter<T> swipe(Swipe<T> swipeListener) {
    this.swipeListener = swipeListener;
    return this;
  }

  public PromiseAdapter onAfterInitListener(OnAfterInitListener onAfterInitListener) {
    this.onAfterInitListener = onAfterInitListener;
    return this;
  }

  public PromiseAdapter<T> alternatingColor(int color) {
    this.alternatingColor = color;
    return this;
  }

  private void indexList() {
    indexer = new Indexer();
    indexer.index();
  }

  public void add(final T t) {
    indexer.add(Conditions.checkNotNull(t));
  }

  public void unshift(final T t) {
    indexer.unshift(Conditions.checkNotNull(t));
  }

  public void add(final List<T> list) {
    indexer.add(Conditions.checkNotNull(list));
  }

  public void remove(final T t) {
    indexer.remove(Conditions.checkNotNull(t));
  }

  public void updateAll() {
    indexer.updateAll();
  }

  public void update(final T t) {
    indexer.update(Conditions.checkNotNull(t));
  }

  public void clear() {
    indexer.clear();
  }

  @Override
  public int getItemViewType(int position) {
    ViewableInstance<T> t = list.get(position);
    int viewType = t.viewable().layout();
    Conditions.checkState(viewType != 0, "The layout resource for " + t + " is not provided");
    return viewType;
  }

  @NonNull
  @Override
  public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false);
    if (onAfterInitListener != null) onAfterInitListener.onAfterInit(view);
    return new Holder(view);
  }

  @Override
  public void onAttachedToRecyclerView(@NonNull RecyclerView recyclerView) {
    super.onAttachedToRecyclerView(recyclerView);
    RecyclerView.LayoutManager manager = recyclerView.getLayoutManager();
    if (manager instanceof GridLayoutManager) {
      GridLayoutManager manager1 = (GridLayoutManager) manager;
      recyclerView.setLayoutManager(new WrapContentGridLayoutManager(recyclerView.getContext(), manager1.getSpanCount()));
    } else if (manager instanceof LinearLayoutManager)
      recyclerView.setLayoutManager(new WrapContentLinearLayoutManager(recyclerView.getContext()));
    /*if (recyclerView.getItemAnimator() != null) {
      recyclerView.setItemAnimator(new CustomItemAnimator());
    }*/
    if (swipeListener != null) {
      ItemTouchHelper.SimpleCallback simpleCallback =
          new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(
                RecyclerView recyclerView,
                RecyclerView.ViewHolder viewHolder,
                RecyclerView.ViewHolder target) {
              return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
              if (viewHolder instanceof PromiseAdapter.Holder) {
                final Holder holder = (Holder) viewHolder;
                Response response = () -> update(holder.t.instance());
                switch (direction) {
                  case ItemTouchHelper.RIGHT:
                    swipeListener.onSwipeRight(holder.t.instance(), response);
                    break;
                  case ItemTouchHelper.LEFT:
                    swipeListener.onSwipeLeft(holder.t.instance(), response);
                    break;
                }
              }
            }
          };
      new ItemTouchHelper(simpleCallback).attachToRecyclerView(recyclerView);
    }
  }

  @Override
  public void onBindViewHolder(@NonNull Holder holder, int position) {
    ViewableInstance<T> t = list.get(position);
    if (alternatingColor != 0)
      if (position % 2 == 1) holder.view.setBackgroundColor(alternatingColor);
    holder.bind(t);
    holder.bindListener(t);
    holder.bindLongClickListener(t);
    if (anim != null) {
      Animator animator = new Animator(holder.view, anim);
      animator.setAnimDuration(animDuration == null ? AnimDuration.standard() : animDuration);
      animator.setWaitDuration(waitDuration == null ? AnimDuration.noDuration() : waitDuration);
      animator.animate();
    }
  }

  @Override
  public int getItemCount() {
    return indexer.size();
  }

  public List<T> getList() {
    return list.map(ViewableInstance::instance);
  }

  public void setList(List<T> list) {
    this.indexer.setList(list);
  }

  public Listener<T> getListener() {
    return listener;
  }

  public void setListener(Listener<T> listener) {
    this.listener = listener;
  }

  public boolean isReverse() {
    return indexer.reverse;
  }

  private void setReverse(boolean reverse) {
    this.indexer.reverse(reverse);
  }

  public LongClickListener<T> getLongClickListener() {
    return longClickListener;
  }

  public void setLongClickListener(LongClickListener<T> longClickListener) {
    this.longClickListener = longClickListener;
  }

  public void reverse() {
    indexer.reverse(true);
  }

  public void reverse(boolean reverse) {
    indexer.reverse(reverse);
  }

  public Anim getAnim() {
    return anim;
  }

  public void setAnim(Anim anim) {
    this.anim = anim;
  }

  public AnimDuration getAnimDuration() {
    return animDuration;
  }

  public void setAnimDuration(AnimDuration animDuration) {
    this.animDuration = animDuration;
  }

  public AnimDuration getWaitDuration() {
    return waitDuration;
  }

  public void setWaitDuration(AnimDuration waitDuration) {
    this.waitDuration = waitDuration;
  }

  public interface Listener<T> {
    void onClick(T t, @IdRes int id);
  }

  public interface OnAfterInitListener {
    void onAfterInit(View view);
  }

  public interface Response {
    void call();
  }

  public interface Swipe<T> {
    void onSwipeRight(T t, Response response);

    void onSwipeLeft(T t, Response response);
  }

  public interface LongClickListener<T> {
    void onLongClick(T t, @IdRes int id);
  }

  public class Holder extends RecyclerView.ViewHolder {
    public View view;
    ViewableInstance<T> t;

    public Holder(View itemView) {
      super(itemView);
      view = itemView;
    }

    void bind(ViewableInstance<T> t) {
      this.t = t;
      t.viewable().init(view);
      t.viewable().bind(view);
    }

    void bindListener(final ViewableInstance<T> t) {
      if (listener == null) return;
      List<Field> fields = new List<>(Arrays.asList(t.getClass().getDeclaredFields()));
      for (Field field : fields)
        try {
          Object view = field.get(t);
          if (view instanceof View)
            ((View) view)
                .setOnClickListener(
                    v -> listener.onClick(t.instance(), v.getId()));
        } catch (IllegalAccessException ignored) {
          /*LogUtil.e(TAG, "illegal access ", ignored);*/
        }
    }

    void bindLongClickListener(final ViewableInstance<T> t) {
      if (longClickListener == null) return;
      List<Field> fields = new List<>(Arrays.asList(t.getClass().getDeclaredFields()));
      for (Field field : fields)
        try {
          Object view = field.get(t);
          if (view instanceof View)
            ((View) view)
                .setOnLongClickListener(
                    v -> {
                      longClickListener.onLongClick(t.instance(), v.getId());
                      return true;
                    });
        } catch (IllegalAccessException ignored) {
        }
    }
  }

  private class Indexer {
    boolean reverse = false;

    void index() {
      for (int i = 0; i < list.size(); i++) list.get(i).viewable().index(i);
    }

    void add(T t) {
      if (list == null) list = new List<>();
      if (!list.isEmpty()) {
        if (reverse) list.reverse();
        list.add(new ViewableInstance<>(t));
        if (reverse) list.reverse();
        index();
        Promise.instance().executeOnUi(PromiseAdapter.this::notifyDataSetChanged);
      } else {
        ViewableInstance<T> instance = new ViewableInstance<>(t);
        list.add(instance);
        instance.viewable().index(0);
        Promise.instance().executeOnUi(() -> notifyItemInserted(0));
      }
    }

    void unshift(T t) {
      if (list == null) list = new List<>();
      if (!list.isEmpty()) {
        List<T> list1 = new List<>();
        list1.add(t);
        list1.addAll(list.map(ViewableInstance::instance));
        setList(list1);
        index();
        Promise.instance().executeOnUi(PromiseAdapter.this::notifyDataSetChanged);
      } else {
        add(t);
      }
    }

    void setList(List<T> list) {
      PromiseAdapter.this.list = list.map(ViewableInstance::new);
      index();
      Promise.instance().executeOnUi(PromiseAdapter.this::notifyDataSetChanged);
    }

    void remove(final T t) {
      if (list == null) return;
      if (t instanceof Viewable) {
        Viewable viewable = (Viewable) t;
        list.remove(viewable.index());
        index();
        Promise.instance().executeOnUi(() -> notifyItemRemoved(viewable.index()));
      }
    }

    void update(final T t) {
      if (list == null) return;
      ViewableInstance<T> v = list.find(i -> i.instance() == t);
      if (v == null) return;
      if (v.viewable().index() >= list.size()) return;
      list.set(v.viewable().index(), v);
      /*notifyItemChanged(t.index());*/
      Promise.instance().executeOnUi(PromiseAdapter.this::notifyDataSetChanged);
    }

    void updateAll() {
      Promise.instance().executeOnUi(PromiseAdapter.this::notifyDataSetChanged);
    }

    void add(List<T> list) {
      for (T t : list) add(t);
    }

    void clear() {
      if (list == null || list.isEmpty()) return;
      list.clear();
      Promise.instance().executeOnUi(PromiseAdapter.this::notifyDataSetChanged);
    }

    int size() {
      return list == null || list.isEmpty() ? 0 : list.size();
    }

    void reverse(boolean reverse) {
      this.reverse = reverse;
    }
  }

  public class WrapContentLinearLayoutManager extends LinearLayoutManager {
    public WrapContentLinearLayoutManager(Context context) {
      super(context);
    }

    public WrapContentLinearLayoutManager(Context context, int orientation, boolean reverseLayout) {
      super(context, orientation, reverseLayout);
    }

    @Override
    public void onLayoutChildren(RecyclerView.Recycler recycler, RecyclerView.State state) {
      try {
        super.onLayoutChildren(recycler, state);
      } catch (IndexOutOfBoundsException e) {
        LogUtil.e(TAG, "meet a Bug in RecyclerView");
      }
    }
  }

  public class WrapContentGridLayoutManager extends GridLayoutManager {

    public WrapContentGridLayoutManager(Context context, int spanCount) {
      super(context, spanCount);
    }

    @Override
    public void onLayoutChildren(RecyclerView.Recycler recycler, RecyclerView.State state) {
      try {
        super.onLayoutChildren(recycler, state);
      } catch (IndexOutOfBoundsException e) {
        LogUtil.e(TAG, "meet a Bug in RecyclerView");
      }
    }
  }

  public class CustomItemAnimator extends DefaultItemAnimator {
    @Override
    public boolean animateChange(
        RecyclerView.ViewHolder oldHolder,
        RecyclerView.ViewHolder newHolder,
        int fromX,
        int fromY,
        int toX,
        int toY) {
      if (getSupportsChangeAnimations()) {
        return super.animateChange(oldHolder, newHolder, fromX, fromY, toX, toY);
      } else {
        if (oldHolder == newHolder) {
          if (oldHolder != null) {
            // if the two holders are equal, call dispatch change only once
            dispatchChangeFinished(oldHolder, /*ignored*/ true);
          }
        } else {
          // else call dispatch change once for every non-null holder
          if (oldHolder != null) {
            dispatchChangeFinished(oldHolder, true);
          }
          if (newHolder != null) {
            dispatchChangeFinished(newHolder, false);
          }
        }
        // we don't need a call to requestPendingTransactions after this, return false.
        return false;
      }
    }
  }
}