package promise.promiseui.model

import android.view.View

interface ViewableCallback<T, V : ViewHolder> {

  fun init(view: View): V

  fun onBind(t: T, view: V)
}


//
//  class Sample {
//    public static ViewableCallback<Object> instance() {
//      return new ViewableCallback<Object>() {
//        @Override
//        public ViewHolder init(View view) {
//          return null;
//        }
//
//        @Override
//        public void onBind(Object o, ViewHolder view) {
//
//        }
//      };
//    }
//  }

