package promise.promiseui.model

import android.view.View
import promise.commons.createInstance

class ViewableInstance<T>(private val t: T) {

  private val viewable: Viewable

  private fun convert(t: Any): Viewable {
    if (t is Viewable)
      return t
    else if (t.javaClass.isAnnotationPresent(promise.promiseui.scopes.Viewable::class.java)) {
      val annotation = t.javaClass.getAnnotation(promise.promiseui.scopes.Viewable::class.java)
      val callback: ViewableCallback<Any, ViewHolder> = createInstance(clazz = annotation!!.viewableCallbackClass::class)
      return object : Viewable {

        var index = 0

        lateinit var viewHolder: ViewHolder

        override fun layout(): Int = annotation.layout

        override fun init(view: View) {
          viewHolder = callback.init(view)
        }

        override fun bind(view: View) {
          callback.onBind(t, viewHolder)
        }

        override fun index(index: Int) {
          this.index = index
        }

        override fun index(): Int = index
      }
    }

    throw IllegalStateException("$t must be an instance on Viewable or have Viewable annotation")
  }

  init {
    this.viewable = convert(t as Any)
  }

  fun viewable(): Viewable = viewable

  fun instance(): T = t
}
