package promise.promiseui.scopes;

import androidx.annotation.LayoutRes;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import promise.promiseui.model.ViewableCallback;

@Target(value = {ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Viewable {

  @LayoutRes int layout() default 0;

  Class<? extends ViewableCallback> viewableCallbackClass() default ViewableCallback.class;
}
